package com.backend;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Question3
 */
@WebServlet("/Question3")
public class Question3 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String answer3 = request.getParameter("answer3");
		
		session.setAttribute("answer3", answer3);
		
		int marks = 0;
		
		String correctAns1 = (String) session.getAttribute("correctAns1");
		String correctAns2 = (String) session.getAttribute("correctAns2");
		String correctAns3 = (String) session.getAttribute("correctAns3");
		
		String answer1 = (String) session.getAttribute("answer1");
		String answer2 = (String) session.getAttribute("answer2");
		String answers3 = (String) session.getAttribute("answer3");
		
		if (correctAns1.equals(answer1)) {
			marks++;
		}
		if (correctAns2.equals(answer2)) {
			marks++;
		}
		if (correctAns3.equals(answer3)) {
			marks++;
		}
		
		
		session.setAttribute("mark", marks);
		
		response.getWriter().println(marks);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("Result.jsp");
		dispatcher.forward(request, response);
	}

}