package com.dxc.dao;
import com.dxc.model.*;

public interface UsersDAO 
{
	public boolean validate(String userName, String password);

}
