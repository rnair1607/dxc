package com.dxc.dao;
import com.dxc.model.*;
import java.util.*;

public interface TrainingDAO 
{
	
	public List<Training> getAllRecord();
	public void updatePercentage(int sapId,int percentage);
	

}
