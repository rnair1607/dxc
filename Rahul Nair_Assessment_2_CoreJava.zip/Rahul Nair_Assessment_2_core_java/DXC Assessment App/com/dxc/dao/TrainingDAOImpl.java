package com.dxc.dao;
import java.sql.*;
import java.util.*;
import com.dxc.dbcon.*;
import com.dxc.model.*;


public class TrainingDAOImpl implements TrainingDAO
{
	Connection connection = DBConnection.getConnection();
	private static final String FETCH_DATA_TRAINING = "select * from training";
	
	public TrainingDAOImpl() 
	{
		
	}
	
	List<Training> allTrainings = new ArrayList<Training>();
	
	public List<Training> getAllRecord(){
		
		List<Training> allTrainings = new ArrayList<Training>();
		
		try {
			Statement stat = connection.createStatement();
			ResultSet res = stat.executeQuery(FETCH_DATA_TRAINING);
			while(res.next()) {
				
				Training training = new Training();
				training.setSapId(res.getInt(1));
				training.setEmpName(res.getString(2));
				training.setStream(res.getString(3));
				training.setPercentage(res.getInt(4));
				allTrainings.add(training);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return allTrainings;
	
		
	}
	
	public void updatePercentage(int sapId,int percentage) {
		
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("update training set percentage=? where sapId=?");
			preparedStatement.setInt(1, percentage);
			preparedStatement.setInt(2, sapId);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
