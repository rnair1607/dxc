package com.dxc.main;
import java.util.*;
import com.dxc.dao.*;
import com.dxc.dbcon.*;
import java.sql.*;
import com.dxc.model.*;


public class Main 
{
	
	public Main() 
	{
		
	}

	public static void main(String[] args) 
	{
		TrainingDAO trainingDAO = new TrainingDAOImpl();
		UsersDAO usersDAO = new UsersDAOImpl();
		
		
		
		if(loginApp()) {
			while(true) {
			System.out.println("\n***********Welcome to Training Assessment App**********");
			System.out.println("1. Display all Training Records");
			System.out.println("2. Display Records one by one and update the Percentage");
			System.out.println("3. EXIT");
			System.out.println("*******************************************************");
			
			Scanner sc = new Scanner(System.in);
			int choice = 0;
			System.out.println("Choose one option: ");
			choice = sc.nextInt();
			
			switch(choice) 
			{
			case 1:
				System.out.println(trainingDAO.getAllRecord());
				break;
				
			case 2:
				List<Training> allTrainingRecord = new ArrayList<Training>();
				
				allTrainingRecord = trainingDAO.getAllRecord();
				Iterator<Training> iterator = allTrainingRecord.iterator();
				
				while(iterator.hasNext()) {
					
					Training training = new Training();
					training = iterator.next();
					
					System.out.println(training.toString());
					if(training.getPercentage()==0) {
						
						System.out.print("Please enter the percentage: ");
						int percentage = sc.nextInt();
						trainingDAO.updatePercentage(training.getSapId(),percentage);
					}
					else {
						System.out.println("Percentages already exist.");
					}
					
				}
				
				break;
				
			case 3:
				System.out.println("Thank you");
				System.exit(0);
				break;
				
			default:
				System.out.println("Invalid Option");
			
			}
			
			}
		}
	}

	
	
	
	
	
	
	
	
	
	
	
	private static boolean loginApp() {
		UsersDAO usersDAO = new UsersDAOImpl();
		Scanner sc = new Scanner(System.in);
		System.out.println("Username: ");
		String userName = sc.next();
		System.out.println("Password: ");
		String password = sc.next();
		 if(usersDAO.validate(userName, password)) {
			 
			 return true;
		 }
		 else {
			 System.out.println("Invalid Username or Password.");
			 return false;
			 
		 }
	}

}
