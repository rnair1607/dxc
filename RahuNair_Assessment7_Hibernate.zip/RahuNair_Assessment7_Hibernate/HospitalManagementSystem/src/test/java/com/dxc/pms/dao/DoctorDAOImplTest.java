package com.dxc.pms.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.dxc.pms.model.Doctor;
import com.dxc.pms.model.HospitalDetails;


import junit.framework.TestCase;

public class DoctorDAOImplTest extends TestCase {
	DoctorDAOImpl impl;

	protected void setUp() throws Exception {
		impl = new DoctorDAOImpl();
	}

	protected void tearDown() throws Exception {
		impl = null;
	}

	public void testGetDoctor() {
		Doctor doctor1 = new Doctor(36534533,"Ron",32);
		impl.addDoctor(doctor1);
		Doctor doctor2 = impl.getDoctor(36534533);
		assertEquals(doctor2.getDoctorId(),doctor1.getDoctorId());
	}

	public void testGetAllDoctors() {
		int size = impl.getAllDoctors().size();
		Doctor doctor1 = new Doctor(2,"Something",12);
		Doctor doctor2 = new Doctor(1,"Some",2);
		impl.addDoctor(doctor1);
		impl.addDoctor(doctor2);
		int size2 = impl.getAllDoctors().size();
		assertEquals(size2, size+2);
		}

	public void testAddDoctor() {
		List<Doctor> doctors = impl.getAllDoctors();
		
		Doctor doctor = new Doctor(100, "Vaibhav", 100);
		Set<HospitalDetails> hospitalDetails = new HashSet<HospitalDetails>();
		hospitalDetails.add(new HospitalDetails("Ramaiah", "Bangalore"));
		doctor.setHospitalDetails(hospitalDetails);
		
		impl.addDoctor(doctor);
		
		List<Doctor> testDoctors = impl.getAllDoctors();
		
		impl.deleteDoctor(100);
		assertEquals(doctors.size() + 1, testDoctors.size());
	}

	public void testDeleteDoctor() {
		int size = impl.getAllDoctors().size();
		int doctorId = 4;
		impl.deleteDoctor(doctorId);
		int size2 = impl.getAllDoctors().size();
		assertEquals(size2, size-1);
	}

	public void testUpdateDoctor() {
		Doctor doctor1 = new Doctor(121,"retry",5);
		Doctor doctor2 = new Doctor(121,"r",6);
		
		impl.addDoctor(doctor1);
		impl.updateDoctor(doctor2);
		Doctor testDoctor = impl.getDoctor(121);
		
		assertSame(doctor2,testDoctor);
	}

	public void testIsDoctorExists() {
		Doctor doctor = new Doctor(100,"Vaibhav",100);
		Set<HospitalDetails> hospitalDetails = new HashSet<HospitalDetails>();
		hospitalDetails.add(new HospitalDetails("Ramaiah","Bangalore"));
		doctor.setHospitalDetails(hospitalDetails);
		
		impl.addDoctor(doctor);
		
		Doctor testDoctor = impl.getDoctor(100);
		impl.deleteDoctor(100);
		assertEquals(doctor,testDoctor);
	}

	public void testGetDoctorByName() {
		Doctor doctor1 = new Doctor(567,"Ron",32);
		impl.addDoctor(doctor1);
		Doctor doctor2 = impl.getDoctorByName("Ron");
		assertEquals(doctor2.getDoctorName(),doctor1.getDoctorName());	
		}

}
