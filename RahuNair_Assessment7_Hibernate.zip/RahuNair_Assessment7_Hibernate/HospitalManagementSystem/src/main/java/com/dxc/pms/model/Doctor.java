package com.dxc.pms.model;

import java.util.Set;

import javax.persistence.*;

import org.hibernate.search.annotations.IndexedEmbedded;

@Entity
public class Doctor {
	@Id
	private int doctorId;
	
	private String doctorName;
	private int fees;
	@ElementCollection
	@IndexedEmbedded
	private Set<HospitalDetails> hospitalDetails;
	
	public Doctor() {
		super();
	}

	public Doctor(int doctorId, String doctorName, int fees) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.fees = fees;
		
	}

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public int getFees() {
		return fees;
	}

	public void setFees(int fees) {
		this.fees = fees;
	}

	public Set<HospitalDetails> getHospitalDetails() {
		return hospitalDetails;
	}

	public void setHospitalDetails(Set<HospitalDetails> hospitalDetails) {
		this.hospitalDetails = hospitalDetails;
	}

	@Override
	public String toString() {
		return "Doctor [doctorId=" + doctorId + ", doctorName=" + doctorName + ", fees=" + fees + ", hospitalDetails="
				+ hospitalDetails + "]";
	}
	
	
	
	

}
