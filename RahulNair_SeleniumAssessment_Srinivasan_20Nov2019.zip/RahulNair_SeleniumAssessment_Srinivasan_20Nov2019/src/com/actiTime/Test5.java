package com.actiTime;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Test5 {
	
	SoftAssert st = new SoftAssert();
	public WebDriver driver;
	public String Browser="chrome";
	@Test
	public void testcase(){
		SoftAssert st=new SoftAssert();
		if(Browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver=new ChromeDriver(); //OpenBrowser
		}else if(Browser.equalsIgnoreCase("mozilla")){
			System.setProperty("webdriver.firefox.marionette", "geckodriver.exe");
			 driver=new FirefoxDriver();
		}else if(Browser.equalsIgnoreCase("ie")){
			System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
			 driver=new InternetExplorerDriver();
		}
		
		
		driver.get("http://127.0.0.1:9000/login.do"); //open url
		driver.manage().window().maximize(); //maximize browser
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
		
		WebElement username = driver.findElement(By.xpath("//input[@name='username']"));
		username.sendKeys("admin");
		
		WebElement password = driver.findElement(By.xpath("//input[@name='pwd']"));
		password.sendKeys("manager");
		
		WebElement login = driver.findElement(By.xpath("//a[@id='loginButton']"));
		login.click();
		
		WebElement tasks = driver.findElement(By.xpath("//a[@class='content tasks']//img[@class='sizer']"));
		tasks.click();
		
		driver.findElement(By.xpath("//a[contains(text(),'Projects & Customers')]")).click();
		driver.findElement(By.xpath("//body/div[@id='container']/form[@id='customersProjectsForm']/table[@class='mainContentPadding rightPadding']/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td/input[2]")).click();
        WebElement selectLocation = driver.findElement(By.xpath("//select[@name='customerId']"));
		
		Select select = new Select(selectLocation);
		select.selectByVisibleText("CustomerA");
		
		driver.findElement(By.xpath("//input[@name='name']")).sendKeys("ProjectB");
		driver.findElement(By.xpath("//textarea[@name='description']")).sendKeys("DescriptionB");
		driver.findElement(By.xpath("//input[@id='add_tasks_action']")).click();
		driver.findElement(By.xpath("//input[@name='createProjectSubmit']")).click();
		
		try{
			driver.findElement(By.xpath(".//*[@id='SuccessMessages']/tbody/tr/td/span")).isDisplayed();
			//Logout
					driver.findElement(By.xpath(".//*[@id='logoutLink']")).click();
			}catch(Throwable t){
				st.fail("Sucess msg does not displayed...");
				//Logout
				driver.findElement(By.xpath(".//*[@id='logoutLink']")).click();
				//cancel creation
				driver.findElement(By.xpath(".//*[@id='DiscardChangesButton']")).click();
			}
		
		driver.quit();
		
		st.assertAll();
	}

}
