package com.dxc.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.ogm.cfg.OgmConfiguration;

import com.dxc.model.Customer;
import com.dxc.model.Employee;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        OgmConfiguration cfg = new OgmConfiguration();
        cfg.configure();
        
        SessionFactory factory = cfg.buildSessionFactory();
        Session session = factory.openSession();
        
        Transaction transaction = session.beginTransaction();
        
        Customer customer = new Customer(19189,"Romit","Bangladesh",96);
        
        session.save(customer);
        transaction.commit();
        
        System.out.println("Data entered in mongoDB using Annotation");
        
    }
}
