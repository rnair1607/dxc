package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.AppConfig;

public class SpringClient {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		Email e = context.getBean(Email.class);
		To t = context.getBean(To.class);
		From f = context.getBean(From.class);
		Subject s = context.getBean(Subject.class);
		Body b = context.getBean(Body.class);
		
		t.setToEmail("ds84@dxc.com");
		t.setToName("Dhanush");
		
		f.setFromEmail("rnair63@dxc.com");
		f.setFromName("Rahul");
		
		s.setCaption("Hello");
		
		b.setMessage("Test Mail");
		
		System.out.println(e);
	}

}
