package com.dxc.pms.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class MovieList 
{
	@Id
	private int movieId;
	@Column
	private String movieName;
	private int budget;
	private String directorName;
	
	public MovieList() 
	{
		super();
	}

	public MovieList(int movieId, String movieName, int budget, String directorName) 
	{
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.budget = budget;
		this.directorName = directorName;
	}

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public int getBudget() {
		return budget;
	}

	public void setBudget(int budget) {
		this.budget = budget;
	}

	public String getDirectorName() {
		return directorName;
	}

	public void setDirectorName(String directorName) {
		this.directorName = directorName;
	}

//	@Override
//	public int hashCode() {
//		final int prime = 31;
//		int result = 1;
//		result = prime * result + ((address == null) ? 0 : address.hashCode());
//		result = prime * result + empId;
//		result = prime * result + ((empName == null) ? 0 : empName.hashCode());
//		result = prime * result + salary;
//		return result;
//	}
//
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		MovieList other = (MovieList) obj;
//		if (address == null) {
//			if (other.address != null)
//				return false;
//		} else if (!address.equals(other.address))
//			return false;
//		if (empId != other.empId)
//			return false;
//		if (empName == null) {
//			if (other.empName != null)
//				return false;
//		} else if (!empName.equals(other.empName))
//			return false;
//		if (salary != other.salary)
//			return false;
//		return true;
//	}

	@Override
	public String toString() {
		return "MovieList [movieId=" + movieId + ", movieName=" + movieName + ", budget=" + budget + ", Director=" + directorName
				+ "]";
	}
	
 
	
	
}
