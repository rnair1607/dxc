package com.dxc.pms.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.pms.config.HibernateUtil;
import com.dxc.pms.model.MovieList;
import com.dxc.pms.model.Product;

public class MovieDAOImpl implements MovieDAO {
	SessionFactory sf =  HibernateUtil.getSessionFactory();

	@Override
	public MovieList getMovie(int movieId) {
		Session session = sf.openSession();
		MovieList movieList = (MovieList) session.get(MovieList.class, movieId);
		return movieList;
	}

	@Override
	public List<MovieList> getAllMovies() {
		Session session = sf.openSession();
		Query query = session.createQuery("from MovieList");
		
		return query.list();
	}

	@Override
	public void addMovie(MovieList movieList) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(movieList);
		transaction.commit();
		session.close();
		System.out.println("Movie Added!");
		
	}

	@Override
	public void deleteMovie(int movieId) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		MovieList movieList = new MovieList();
		movieList.setMovieId(movieId);
		session.delete(movieList);
		transaction.commit();
		session.close();
		
	}

	@Override
	public void updateMovie(MovieList movieList) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(movieList);
		transaction.commit();
		session.close();
		
	}

	@Override
	public boolean isMovieExists(int movieId) {
		Session session = sf.openSession();
		MovieList movieList = (MovieList) session.get(MovieList.class, movieId);
		if(movieList == null) 
			return false;
		else
			return true;
	}
	
}