package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.model.MovieList;

public interface MovieDAO {
		public MovieList getMovie(int movieId);
		public List<MovieList> getAllMovies();
		public void addMovie(MovieList movieList);
		public void deleteMovie(int movieId);
		public void updateMovie(MovieList movieList);
		public boolean isMovieExists(int movieId);
}
