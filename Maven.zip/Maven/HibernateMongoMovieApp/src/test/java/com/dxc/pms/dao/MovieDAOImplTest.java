package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.model.MovieList;
import com.dxc.pms.model.Product;

import junit.framework.TestCase;

public class MovieDAOImplTest extends TestCase {
	MovieDAO impl;

	protected void setUp() throws Exception {
		impl = new MovieDAOImpl();
		
	}

	protected void tearDown() throws Exception {
		impl = null;
	}

	public void testGetMovie() {
		MovieList movieList1 = new MovieList(11,"Ronal",321,"Ron");
		impl.addMovie(movieList1);
		MovieList movieList2 = impl.getMovie(11);
		assertEquals(movieList2.getMovieId(),movieList1.getMovieId());
	}

	public void testGetAllMovies() {
		int size = impl.getAllMovies().size();
		MovieList movieList1 = new MovieList(21,"Ronal1",3211,"Ron1");
		MovieList movieList2 = new MovieList(31,"Ronal2",3221,"Ron2");
		impl.addMovie(movieList1);
		impl.addMovie(movieList2);
		int size2 = impl.getAllMovies().size();
		assertEquals(size2, size+2);
	}

	public void testAddMovie() {
		MovieList movieList1 = new MovieList(41,"Ronal3",3123,"Ron3");
		List<MovieList> allMovies1 = impl.getAllMovies();
		impl.addMovie(movieList1);
		List<MovieList> allMovies2 = impl.getAllMovies();
		assertNotSame(allMovies2.size(), allMovies1.size());
	}

	public void testDeleteMovie() {
		MovieList movieList1 = new MovieList(413,"Ronal3",3123,"Ron3");
		impl.addMovie(movieList1);
		int size = impl.getAllMovies().size();
		int movieId = 413;
		impl.deleteMovie(movieId);
		int size2 = impl.getAllMovies().size();
		assertEquals(size-1,size2);
	}

	public void testUpdateMovie() {
		MovieList movieList1 = new MovieList(1211,"retry",51,"5");
		MovieList movieList2 = new MovieList(1211,"r",61,"6");
		
		impl.addMovie(movieList1);
		impl.updateMovie(movieList2);
		MovieList testMovie = impl.getMovie(1211);
		
		assertEquals(movieList2.getDirectorName(),testMovie.getDirectorName());
	}

	public void testIsMovieExists() {
		MovieList movieList1 = new MovieList(1234,"1234",1234,"1234");
		impl.addMovie(movieList1);
		assertEquals(true, impl.isMovieExists(1234));
	}

}
