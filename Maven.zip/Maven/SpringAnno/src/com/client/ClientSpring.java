package com.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.config.AppConfig;
import com.model.Address;
import com.model.Employee;

public class ClientSpring {

	public static void main(String[] args) {
		
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		Employee e = context.getBean(Employee.class);
		Address a = context.getBean(Address.class);
		
		e.setEmpId(90);
		e.setEmpName("Rahul");
		e.setSalary(98000);
		
		a.setCity("Bangalore");
		a.setState("Karnataka");
		
//		e.setAddress(a);
		
		System.out.println(e);

	}

}
