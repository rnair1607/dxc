package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.model.Address;
import com.model.Employee;

@Configuration
public class AppConfig {
	
	@Bean
	public Employee getEmployee() {
		return new Employee();
	}

	@Bean
	public Address getAddress() {
		return new Address();
	}
}
