package com.dxc.client;

public class Addnumbers {
	
	public int sum(int num1,int num2) {
		
		return num1+num2;
	}

	public static void main(String[] args) {
		
		Addnumbers a = new Addnumbers();
		System.out.println(a.sum(23, 23));
		
		

	}

}
