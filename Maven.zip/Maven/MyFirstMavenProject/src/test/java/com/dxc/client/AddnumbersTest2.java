package com.dxc.client;

import junit.framework.TestCase;

public class AddnumbersTest2 extends TestCase {

	public void testSum() {
		fail("Not yet implemented");
	}

}
