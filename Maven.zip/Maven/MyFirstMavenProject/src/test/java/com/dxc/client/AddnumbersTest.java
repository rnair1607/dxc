package com.dxc.client;

import junit.framework.TestCase;

public class AddnumbersTest extends TestCase {

	public void testSum() {
		Addnumbers a = new Addnumbers();
		int res = a.sum(22, 22);
		assertEquals(44, res);
	}

}
