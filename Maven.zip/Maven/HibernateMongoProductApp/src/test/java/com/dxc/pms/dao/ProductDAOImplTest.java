package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.model.Product;

import junit.framework.TestCase;

public class ProductDAOImplTest extends TestCase {
	ProductDAOImpl impl;
	protected void setUp() throws Exception{
		impl = new ProductDAOImpl();
	}

	protected void tearDown() throws Exception{
		impl = null;
	}
	
	public void testGetProduct() {
		Product product1 = new Product(36534533,"Ron",32,32);
		impl.addProduct(product1);
		Product product2 = impl.getProduct(36534533);
		assertEquals(product2.getProductId(),product1.getProductId());
	}

	public void testGetAllProducts() {
		int size = impl.getAllProducts().size();
		Product product1 = new Product(2,"Something",12,22);
		Product product2 = new Product(1,"Some",2,25);
		impl.addProduct(product1);
		impl.addProduct(product2);
		int size2 = impl.getAllProducts().size();
		assertEquals(size2, size+2);
	}

	public void testAddProduct() {
		Product product = new Product(4,"Something",12,22);
		List<Product> allProducts1 = impl.getAllProducts();
		impl.addProduct(product);
		List<Product> allProducts2 = impl.getAllProducts();
		assertNotSame(allProducts2.size(), allProducts1.size());
		
	}

	public void testDeleteProduct() {
		int size = impl.getAllProducts().size();
		int productId = 4;
		impl.deleteProduct(productId);
		int size2 = impl.getAllProducts().size();
		assertEquals(size2, size-1);
		
	}

	public void testUpdateProduct() {
		Product product1 = new Product(121,"retry",5,5);
		Product product2 = new Product(121,"r",6,6);
		
		impl.addProduct(product1);
		impl.updateProduct(product2);
		Product testProduct = impl.getProduct(121);
		
		assertSame(product2,testProduct);
	}

	public void testIsProductExists() {
		fail("Not yet implemented");
	}

}
