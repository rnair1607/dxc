package com.dxc.pms.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.pms.config.HibernateUtil;
import com.dxc.pms.model.Product;

public class ProductDAOImpl implements ProductDAO {
	SessionFactory sf =  HibernateUtil.getSessionFactory();
	

	@Override
	public Product getProduct(int productId) {
		Session session = sf.openSession();
		Product product = (Product) session.get(Product.class, productId);
		return product;
		
		
	}

	@Override
	public List<Product> getAllProducts() {
		Session session = sf.openSession();
		Query query = session.createQuery("from Product");
		
		return query.list();
	}

	@Override
	public void addProduct(Product product) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(product);
		transaction.commit();
		session.close();
		System.out.println("Product Added!");
		
		
		
	}

	@Override
	public void deleteProduct(int productId) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		Product product = new Product();
		product.setProductId(productId);
		session.delete(product);
		transaction.commit();
		session.close();
		
		
	}

	@Override
	public void updateProduct(Product product) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.saveOrUpdate(product);
//		Product productobj = (Product) session.get(Product.class, product.getProductId());
//		
//		productobj.setPrice(product.getPrice());
//		productobj.setProductName(product.getProductName());
//		productobj.setQuantityOnHand(product.getQuantityOnHand());
		
		transaction.commit();
		session.close();
		
		
	}

	@Override
	public boolean isProductExists(int productId) {
		Session session = sf.openSession();
		Product product = (Product) session.get(Product.class, productId);
		if(product == null) 
			return false;
		else
			return true;
	}
	
	}
