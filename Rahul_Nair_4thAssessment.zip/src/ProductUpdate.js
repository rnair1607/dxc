import React, { Component } from 'react';
import './App.css'

class ProductUpdate extends Component{
    constructor(props){
        super(props)
        this.state={

        }
    }

    render(){
        return(
            <React.Fragment>
                <div className="App">
                <from className="form">
                        <label htmlFor="productId">Product ID: <input type="text" id="productId" name="productId" className="form-control"></input></label><br/><span></span>
                        <label htmlFor="quantity">Quantity: <input type="text" id="quantity" name="quantity" className="form-control"></input></label><br/>
                        <button type="submit" className="btn btn-outline-dark" onClick="">Submit</button>
                </from> 
                </div>
            </React.Fragment>
        )
    }
}export default ProductUpdate