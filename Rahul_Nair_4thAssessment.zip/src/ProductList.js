import React, { Component } from 'react';
import ProductDisplay from './ProductDisplay';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import ProductDetails from './ProductDetails';
import ProductUpdate from './ProductUpdate'
class ProductList extends Component {
    constructor(props)
    {
        super(props)
        this.state={
            ProductId : 0,
            Quantity : 0,
            productList : [
                {
                    productId: 1001,
                    productName: 'Watch',
                    quantityOnHand: 2000,
                    price: 10000
                },
                {
                    productId: 1002,
                    productName: 'Mouse',
                    quantityOnHand: 29,
                    price: 180000
                },
                {
                    productId: 1003,
                    productName: 'Laptop',
                    quantityOnHand: 29,
                    price: 122
                },
                {
                    productId: 10113,
                    productName: 'Presenter',
                    quantityOnHand: 29,
                    price: 122
                },
    
                {
                    productId: 111003,
                    productName: 'Marker',
                    quantityOnHand: 29,
                    price: 122
                },
            ]

        }
        
    }

    handleIdChange=(e)=>{
        this.setState({
            ProductId : e.target.value
        })
    }

    handleQuantityChange=(e)=>{
        this.setState({
            Quantity : e.target.value
        })
    }

    handleSubmit=(e)=>{
        e.preventDefault()
        const {productList,ProductId,Quantity} = this.state
        if(this.state.Quantity < 0){
            alert("Invalid Input for Quantity")
            
        }
        // console.log(this.state.productList)
        // console.log(this.state.ProductId)
        // console.log(this.state.Quantity)

        // this.updateProductData(this.state.ProductId,this.state.Quantity)

      var prodList = productList
      prodList[productList.findIndex(x => x.productId == ProductId)].quantityOnHand = Quantity 
      this.setState({
          productList : prodList
      })
    }

    // updateProductData(productId,quantityOnHandToUpdate)
    // {
    //     var arr = this.state.productList
    //     arr[0].quantityOnHand = quantityOnHandToUpdate
    //     this.setState({
    //         productList : arr
    //     })
    // }
    render() {
        
        return (

            <div className="App">
                <table className="table">
                    <thead>
                        <th>
                            <h2><b>Product Id</b></h2>
                        </th>
                        <th>
                            <h2><b>Product Name</b></h2>
                        </th>
                        <th>
                            <h2><b>Quantity</b></h2>
                        </th>
                        <th>
                            <h2><b>Price</b></h2>
                        </th>
                    </thead>
               
                    <tbody>
                {this.state.productList.map((product, index) =>
                    
                        <ProductDisplay render={({ match }) => match={match}}
                            nn={index}
                            key={index}
                            product={product}
                        ></ProductDisplay>
                    

                )}

                <Route path={`${this.props.match.path}/:productName`}
                    render={({ match }) => match={match}} 
                    component={ProductDetails} />
                    </tbody>
               </table>
               <form className="form" >
                        <label htmlFor="productId">Product ID: <input type="text" id="productId" name="productId"  className="form-control" onChange={this.handleIdChange}></input></label><br/><span></span>
                        <label htmlFor="quantity">Quantity: <input type="text" id="quantity" name="quantity"  className="form-control" onChange={this.handleQuantityChange}></input></label><br/>
                        <button type="button" onClick={this.handleSubmit} className="btn btn-outline-dark" >Submit</button>
                </form> 
            </div>
            

        );
    }
}
export default ProductList;
