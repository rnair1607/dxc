import React, { Component } from 'react';

class ProductDisplay extends Component {
    
    render() {
        const {nn,product} = this.props
        return (
            <React.Fragment>
                    <tr>
                
                        <td >{product.productId}</td>
                        <td>{product.productName}</td>
                        <td>{product.quantityOnHand}</td>
                        <td>{product.price}</td>
                    </tr>
                
               
                    
            </React.Fragment>
        );
    }
}

export default ProductDisplay;