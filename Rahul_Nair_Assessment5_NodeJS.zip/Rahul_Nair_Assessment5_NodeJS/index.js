var express = require('express')
var app = express()
var fs = require('fs')

app.set("view engine","ejs")

var text = fs.readFileSync('./resources/about.txt','utf-8')
app.get("/",function(req,res){
    res.render("about",{text:text})
})

app.listen(8000)