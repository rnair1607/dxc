package day11Assignment;

public class Bus extends Vehicle {
	
	private String fuelType;
	private String type;

	public Bus() {
		// TODO Auto-generated constructor stub
	}

	public Bus(String color, int numOfWheels, int model) {
		super(color, numOfWheels, model);
		// TODO Auto-generated constructor stub
	}

	public String getFuelType() {
		return fuelType;
	}

	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Bus \nfuelType: " + fuelType + "\ntype: " + type + "\nColor:" + getColor() + "\nNumOfWheels: "
				+ getNumOfWheels() + "\nModel: " + getModel() ;
	}

	
	
	

}
