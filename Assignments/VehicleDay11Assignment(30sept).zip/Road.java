package day11Assignment;

public class Road {

	public static void main(String[] args) {
		
		Truck truck = new  Truck("Red",8,2003);
		truck.setCargoCapacity(2);
		truck.setOil(5);
		
		Bus bus = new Bus("Yellow",6,2009);
		bus.setFuelType("Diesel");
		bus.setType("AC Volvo");
		
		Car car = new Car("Black",4,2017);
		car.setBrakeSystem("ABS");
		car.setCarClass("Sedan");
		
		System.out.println(car);
		System.out.println(bus);
		System.out.println(truck);
	}

}
