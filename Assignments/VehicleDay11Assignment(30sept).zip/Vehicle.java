package day11Assignment;

public class Vehicle {
	
	private String color;
	private int numOfWheels;
	private int model;
	
	public Vehicle() {
		super();
	}

	public Vehicle(String color, int numOfWheels, int model) {
		super();
		this.color = color;
		this.numOfWheels = numOfWheels;
		this.model = model;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getNumOfWheels() {
		return numOfWheels;
	}

	public void setNumOfWheels(int numOfWheels) {
		this.numOfWheels = numOfWheels;
	}

	public int getModel() {
		return model;
	}

	public void setModel(int model) {
		this.model = model;
	}

	@Override
	public String toString() {
		return "Vehicle \ncolor: " + color + "\nnumOfWheels: " + numOfWheels + "\nmodel: " + model ;
	}

	
	
	
	
	

}
