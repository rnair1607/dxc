package day11Assignment;

public class Truck extends Vehicle {

	private int cargoCapacity;
	private int oil;
	
	public Truck() {
		// TODO Auto-generated constructor stub
	}

	public Truck(String color, int numOfWheels, int model) {
		super(color, numOfWheels, model);
		// TODO Auto-generated constructor stub
	}

	public int getCargoCapacity() {
		return cargoCapacity;
	}

	public void setCargoCapacity(int cargoCapacity) {
		this.cargoCapacity = cargoCapacity;
	}

	public int getOil() {
		return oil;
	}

	public void setOil(int oil) {
		this.oil = oil;
	}

	@Override
	public String toString() {
		return "Truck \ncargoCapacity: " + cargoCapacity + "\noil: " + oil + "\nColor: " + getColor()
				+ "\nNumOfWheels: " + getNumOfWheels() + "\nModel: " + getModel() ;
	}

	
	

	
}
