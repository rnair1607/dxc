package day11Assignment;

public class Car extends Vehicle {
	
	private String carClass;
	private String  brakeSystem;

	public Car() {
		// TODO Auto-generated constructor stub
	}

	public Car(String color, int numOfWheels, int model) {
		super(color, numOfWheels, model);
		// TODO Auto-generated constructor stub
	}

	public String getCarClass() {
		return carClass;
	}

	public void setCarClass(String carClass) {
		this.carClass = carClass;
	}

	public String getBrakeSystem() {
		return brakeSystem;
	}

	public void setBrakeSystem(String brakeSystem) {
		this.brakeSystem = brakeSystem;
	}

	@Override
	public String toString() {
		return "Car \ncarClass: " + carClass + "\nbrakeSystem: " + brakeSystem + "\nColor: " + getColor()
				+ "\nNumOfWheels: " + getNumOfWheels() + "\nModel: " + getModel() ;
	}

	

	
}
